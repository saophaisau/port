﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LeagueSharp;
using LeagueSharp.Common;
using SharpDX;
using Color = System.Drawing.Color;

namespace BadaoKingdom.BadaoChampion.BadaoGangplank
{
    public static class BadaoGangplankVariables
    {
        public static bool ComboE1;
        public static bool HarassQ;
        public static bool JungleQ;
        public static bool LaneQ;
        public static bool AutoWLowHealth;
        public static int AutoWLowHealthValue;
        public static bool AutoWCC;
    }
}
